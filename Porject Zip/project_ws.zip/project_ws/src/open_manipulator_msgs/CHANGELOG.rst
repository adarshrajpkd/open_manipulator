^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package open_manipulator_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.1 (2021-06-24)
------------------
* Noetic support
* Contributors: Will Son

1.0.0 (2019-02-08)
------------------
* added endeffector name
* added params
* added authors
* added path time variable
* deleted unused params
* updated msg and srv
* updated the CHANGELOG and version to release binary packages
* Contributors: Darby Lim, Yong-Ho Na, Pyo

0.3.0 (2018-06-01)
------------------
* Package reconfiguration for OpenManipulator
* Contributors: Darby Lim, Pyo

0.1.1 (2018-03-15)
------------------
* none

0.1.0 (2018-03-14)
------------------
* modified dynamixel controller
* modified msgs and description
* modified cmake, package files for release
* refactoring for release
* Contributors: Darby Lim, Pyo
