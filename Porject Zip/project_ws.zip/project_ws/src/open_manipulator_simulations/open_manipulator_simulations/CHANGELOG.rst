^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package open_manipulator_simulations
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.1.1 (2021-06-25)
------------------
* Noetic support
* Contributors: Will Son

1.1.0 (2019-02-08)
------------------
* added subscriber for gripper control `#3 <https://github.com/ROBOTIS-GIT/open_manipulator_simulations/issues/3>`_
* added pid gain for gazebo controller
* change gripper name
* change effort to position controllers
* Contributors: Darby Lim, Hye-Jong KIM, Pyo

1.0.0 (2018-06-01)
------------------
* package reconfiguration for OpenManipulator
* Contributors: Darby Lim

0.1.1 (2018-03-15)
------------------
* none

0.1.0 (2018-03-14)
------------------
* modified gazebo dependency
* update gazebo
* update moveit
* modified cmake, package files for release
* refactoring for release
* Contributors: Darby Lim, Pyo
